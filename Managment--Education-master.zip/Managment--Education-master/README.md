#Education--Schoool-Managment-Template

>HTML Template for education purpose website or portal. It is suitable for Education Course related projects and it includes web elements which helps you to build your own site.This education template has everything you need to start your next upcoming education project.


#Pages<br>

1.Home<br>
2.About<br>
3.Academic<br>
4.Exam Routine<br>
5.Class wise Book <br>
6.Result<br>
7.Gallery<br>
8.Tution fee<br>
9.contact<br>
10.Library<br>


#features:<br>

✔HTML5 & CSS3<br> 
✔Responsive Design <br>
✔User Friendly Code<br> 
✔Clean Markup<br> 
✔Cross Browser Support<br> 
✔Powered With Bootstrap 3 <br>
✔Used font awesome icon<br> 
✔Google Font <br>
✔Google Map <br>
✔Smooth animation<br>   
✔And Much More!<br>

#Source & Credits<br>

1.BootStrap 3<br>
2.Google font<br> 
4Jquery Library<br>
5.Font Awesome<br>

